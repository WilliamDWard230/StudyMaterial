#include<iostream>
using namespace std; 

struct pubStruct {  
    int number = 5; 
};

struct privStruct { 
    private: 
        int number = 5; 
};

class pubClass { 
    public:
        int number = 5; 
};

class privClass {
    int number = 5; 
};

int main() { 
    pubStruct publicStruct; 
    privStruct privateStruct; 
    pubClass publicClass; 
    privClass privateClass; 

    cout << publicStruct.number << endl; 
    cout << publicClass.number << endl; 

    // These two will cause the program to not compile, as the private variables are accessed outside of the class itself. 
    cout << privateStruct.number << endl; 
    cout << privateClass.number << endl; 

    return 0;

}