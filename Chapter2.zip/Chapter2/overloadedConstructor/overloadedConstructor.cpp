// Brandon Vandergriff
// 6/21/2024
// An example of operator overloading. 

// includes 
#include<iostream>

// technically not good programming practice
using namespace std; 

class Vehicle { 

    private:
        string make; 
        int year;
        double weight; 

    

    public:

    Vehicle () { 
        this->make = "N/A";
        this->year = 0;
        this->weight = 0.0;
    }

    ~Vehicle ( ) {
        cout << " Sending the " << this->make  << " to the junkyard. " << endl; 
    }

    Vehicle (string make, int year, double weight = 6969) { 
        this->make = make; 
        this->year = year;
        // if the user does not specify weight, it will be 6969
        this->weight = weight;
    }

    string getMake() const {
        return this->make;
    }
    int getYear() const {
        return this->year;
    }
    double getWeight() const {
        return this->weight;
    }

    // this overloaded equality operator will check if the vehicles have the same year
    bool operator==(const Vehicle& right_comparison) {
        return this->year == right_comparison.year;
    }

    bool operator<(const Vehicle& right_comparison) {
        return this->year < right_comparison.year; 
    }

    bool operator>(const Vehicle& right_comparison) {
        return this->year > right_comparison.year; 
    }

    friend ostream& operator<<(ostream& os, Vehicle& myVehicle) { 
        os << "MAKE: " << myVehicle.make << endl; 
        return os; 
    }
};

int main() {

    Vehicle blank_vehicle; 

    Vehicle custom_vehicle("Big Truck", 1978, 6142.55); 

    // By not passing in weight, we use the default argument for weight
    Vehicle optional_argument("Tesla", 2014);

    // Limit testing - this will not work. Feel free to uncomment to see the error it throws. 
    //Vehicle broken_vehicle(2014); 

    cout << "PRINTING THE BLANK VEHICLE: " << endl; 
    cout << "MAKE: " << blank_vehicle.getMake() << endl;
    cout << "YEAR: " << blank_vehicle.getYear() << endl;
    cout << "WEIGHT: " << blank_vehicle.getWeight() << endl;

    cout << "PRINTING THE CUSTOM VEHICLE: " << endl; 
    cout << "MAKE: " << custom_vehicle.getMake() << endl;
    cout << "YEAR: " << custom_vehicle.getYear() << endl;
    cout << "WEIGHT: " << custom_vehicle.getWeight() << endl;

    cout << "PRINTING THE OPTIONAL VEHICLE: " << endl; 
    cout << "MAKE: " << optional_argument.getMake() << endl;
    cout << "YEAR: " << optional_argument.getYear() << endl;
    cout << "WEIGHT: " << optional_argument.getWeight() << endl;

    if (custom_vehicle == optional_argument)
        cout << "These vehicles were made in the same year. " << endl; 
    else 
        cout << "These vehicles were NOT made in the same year. " << endl; 

    // SHOWING OFF THE OVERLOADED OUTPUT
    cout << custom_vehicle;

    cout << "\n\n CALLING DESTRUCTOR WHEN PROGRAM ENDS" << endl; 
    return 0; 
}


