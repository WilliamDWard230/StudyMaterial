#ifndef PLANET_H
#define PLANET_H

#include <iostream>
using namespace std;

class Planet
{
    private:
        float minSurfaceTemp; //minimum surface temperature (in Fahrenheit)
        float maxSurfaceTemp; //maximum surface temperature (in Fahrenheit)
        float size; //equatorial radius in miles

    public:
        float getMinSurfaceTemp()
        {
            return minSurfaceTemp;
        }
        float getMaxSurfaceTemp()
        {
            return maxSurfaceTemp;
        }
        float getSize()
        {
            return size;
        }

        void setMinSurfaceTemp(float temp)
        {
            minSurfaceTemp = temp;
        }
        void setMaxSurfaceTemp(float temp)
        {
            maxSurfaceTemp = temp;
        }
        void setSize(float s)
        {
            size = s;
        }

        //overloaded << operator
		friend ostream & operator << (ostream& os, const Planet& p)
		{
			os << "\n\nPLANET SIZE:  " << p.size << "\n";
            os << "WHAT IS UP?\n";
			return os;
		}

};

#endif