#include <iostream>
#include "planet.h"
using namespace std;

int main()
{
    Planet mercury;
    mercury.setMaxSurfaceTemp(800.33);
    mercury.setMinSurfaceTemp(-279.67);
    mercury.setSize(1516.0 );

    cout << "\nMercury\'s maximum surface temperature is " << mercury.getMaxSurfaceTemp() << " degrees Fahrenheit.\n";
    cout << "\nMercury\'s minimum surface temperature is " << mercury.getMinSurfaceTemp() << " degrees Fahrenheit.\n";
    cout << "\nMercury\'s size is " << mercury.getSize() << " miles.\n"; 

    cout << mercury;

    return 0;
}