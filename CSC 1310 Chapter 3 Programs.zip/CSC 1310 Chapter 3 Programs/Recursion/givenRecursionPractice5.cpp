/*
	Write a function that will recursively calculate the 
	sum of all the numbers in the array.
	
	The function will have to accept the array as one of
	it's parameters.
*/

#include <iostream>
using namespace std;

int getTotalArrayElements(?????????????);  //fix this 

const int SIZE = 5;

int main()
{
	int myArr[SIZE] = {7, 14, 1, 5, 3};
	
	cout << "\n\nThe total of the array elements:  ";
	
	//call the function in a cout statement below where I have put XXXXXXXXXXX
	cout << XXXXXXXXXXX << endl << endl;
	
	return 0;
}

int getTotalArrayElements(?????????????) //fix this
{
	//what should go here?
}
