//message.cpp

#include <iostream>

// libraries for sleep() 
// UNCOMMENT FOR OS 
// #include <windows.h> // windows
#include <unistd.h> // linux 

using namespace std;

void message();

int main()
{
	message();
	return 0;
}

void message()
{
	cout << "\nCrazy? I was crazy once.\n";
	cout << "\nThey locked me in a room.\n";
	cout << "\nA rubber room. \n";
	cout << "\nA rubber room with rats. \n";
	cout << "\nAnd rats make me crazy.\n";
	sleep(1);
	message();
}

