//messageFixed.cpp

#include <iostream>
using namespace std;

void message(int);

int main()
{
	message(3);
	
	return 0;
}

void message(int times)
{
	if(times > 0)  //recursive case
	{
		cout << "\nCrazy? I was crazy once.\n";
	cout << "\nThey locked me in a room.\n";
	cout << "\nA rubber room. \n";
	cout << "\nA rubber room with rats. \n";
	cout << "\nAnd rats make me crazy.\n";
		message(times-1);
	}
}

